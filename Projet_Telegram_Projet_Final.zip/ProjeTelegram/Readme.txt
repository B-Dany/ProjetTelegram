					UNIVERSITE INUKA
		Projet web client 1 pour nous familiariser avec la notion internet et le web
				Professeur : BIEN-AIME Rony

Nom		Prenom		Code		Vacation	Niveau Etude
BADIO		Dany		33512		Median A 	2eme Annee Informatiques